# CSI5155

* #### Adrien Heymans
* #### Fall 2022
* #### Pr. Herna L Viktor, PhD
This folder contains the assignement 1 for the class CSI5155 for the Fall 2022 term. 


### Details 

* A readmemd file, this file 
* The folder results contains 4 sub-folders with the results for the 4 differents models, in details 
    * Confusion Matrix
    * ROC curves
    * Classification Report
    * A CSV file giving summary of the results for that specific model 
    * A PNG file that shows the accuracy,recall, and precision compared to the other drugs 
* The folder data contains the data that was used for this execrice 
* A "Report.docx" file, this is the report for the assignement
* The file "2001.06520.pdf", the paper that was used to compare our results 
* The file "CSI5155-Assignment1Fall2022.pdf", the instructions of the assignement
* The file "a1.ipynb", a jupyter notebook containing the source code of the assignemnt